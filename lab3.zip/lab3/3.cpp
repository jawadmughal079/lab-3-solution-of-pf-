#include <iostream>
using namespace std;
int main()
{
    int found = 0, replace = 0, num = 0, index = 0;
    const int size = 10;
    int arr[size] = {1, 2, 3, 4, 5, 6, 7, 8, 12, 4};
    for (int index = 0; index < size; index++) //displaying array
    {
        cout << arr[index] << " ";
    }
    cout << "Enter a number which you want to delete :"; //delted number
    cin >> num;
    for (int i = 0; i < size; i++)
    {
        if (num == arr[i])
        {
            index = i;
            found = 1;
        }
    }
    if (found == 0) //condition checks here
    {

        cout << "value not found ";
    }
    else
    {
        cout << "value found  at  " << index << "index ";
        cout << "\nNow enter a number which you want to replace it with :";
        cin >> replace;
        arr[index] = replace;
        cout << "\nupdated Array :";
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << " ";
        }
    }
    return 0;
}
