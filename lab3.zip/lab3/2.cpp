#include <iostream>
using namespace std;
int main()
{
    int check = 0, count = 0;
    const int size = 5;
    int arr1[size], arr2[size];
    cout << "Enter an array to check they are same or not :";
    for (int index = 0; index < size; index++)
    {
        cin >> arr1[index];
    }
    cout << "\n Enter second array : ";
    for (int index = 0; index < size; index++)
    {
        cin >> arr2[index];
    }
    // checking CONDITION
    for (int i = 0; i < size; i++)
    {
        if (arr1[i] == arr2[i])
        {
            count = 1;
        }
    }

    if (count == 1) //results

    {
        cout << "Arrays are  same";
    }
    else
    {
        cout << "arrays are not same";
    }

    return 0;
}
