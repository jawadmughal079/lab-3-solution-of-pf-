#include <iostream>
using namespace std;
int main()
{
    int check = 0, temp = 0;
    int counter = 1;
    const int size = 5;
    int arr1[size], arr2[size];
    cout << "Enter an array to check they are same or not :"; //array from user
    for (int index = 0; index < size; index++)
    {
        cin >> arr1[index];
    }
    cout << "\n Enter second array : ";
    for (int index = 0; index < size; index++)
    {
        cin >> arr2[index];
    }

    while (counter < size)
    {
        for (int i = 0; i < size - counter; i++)
        {
            if (arr1[i] < arr1[i + 1])
            {
                temp = arr1[i];
                arr1[i] = arr1[i + 1];
                arr1[i + 1] = temp;
            }
        }
        counter++;
    }
    counter = 1;

    while (counter < size)
    {
        for (int i = 0; i < size - counter; i++)
        {
            if (arr1[i] < arr2[i + 1])
            {
                temp = arr1[i];
                arr2[i] = arr1[i + 1];
                arr2[i + 1] = temp;
            }
        }
        counter++;
    }
    for (int i = 0; i < size; i++) //checking arrays are same or not
    {
        if (arr1[i] == arr2[i])
        {
            check = 1;
        }
    }
    if (check == 1) //result
    {
        cout << "arrays are same";
    }
    else
    {
        cout << "Arrays are not same";
    }

    return 0;
}
